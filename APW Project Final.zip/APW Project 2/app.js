const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const MongoClient = require('mongodb').MongoClient;

const app = express();
const PORT = process.env.PORT || 3000;
const mongoURI = 'mongodb://localhost:27017/calendar'; 

// Middleware setup
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB connection
MongoClient.connect(mongoURI, (err, client) => {
    if (err) {
        console.error('Error connecting to MongoDB:', err);
        return;
    }
    console.log('Connected to MongoDB');

    // Define routes after MongoDB connection is established
    app.get('/', (req, res) => {
        res.sendFile(path.join(__dirname, 'public', 'index.html'));
    });

    app.get('/login', (req, res) => {
        res.sendFile(path.join(__dirname, 'public', 'LoginPage_1.html'));
    });

    app.post('/login', (req, res) => {
        const username = req.body.username;
        const password = req.body.password;
        // Perform authentication using MongoDB
        const db = client.db();
        const usersCollection = db.collection('Users'); 
        usersCollection.findOne({ username: username, password: password }, (err, user) => {
            if (err) {
                console.error('Error finding user:', err);
                res.sendStatus(500); // Internal server error
                return;
            }
            if (user) {
                res.redirect('/main'); // Redirect to main page upon successful login
            } else {
                // Handle unsuccessful login
                res.send('Invalid username or password');
            }
        });
    });

    app.get('/main', (req, res) => {
        // Serve your main page here after successful login
        res.sendFile(path.join(__dirname, 'public', 'main.html'));
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
